import cv2
import numpy as np

# Load the images
foreground = cv2.imread('foreground.jpg')
background = cv2.imread('background.jpg')

# Resize background to match foreground
background = cv2.resize(background, (foreground.shape[1], foreground.shape[0]))

# Convert foreground to HSV
hsv = cv2.cvtColor(foreground, cv2.COLOR_BGR2HSV)

# Define range of green color in HSV
lower_green = np.array([35, 40, 40])
upper_green = np.array([85, 255, 255])

# Create a mask to detect green areas
mask = cv2.inRange(hsv, lower_green, upper_green)

# Invert the mask
mask_inv = cv2.bitwise_not(mask)

# Black-out the area of green in foreground
fg = cv2.bitwise_and(foreground, foreground, mask=mask_inv)

# Take only region of background where mask is not present
bg = cv2.bitwise_and(background, background, mask=mask)

# Add the foreground and background
result = cv2.add(fg, bg)

# Save or display the result
cv2.imwrite('output.jpg', result)
# cv2.imshow('Result', result)
# cv2.waitKey(0)
# cv2.destroyAllWindows()